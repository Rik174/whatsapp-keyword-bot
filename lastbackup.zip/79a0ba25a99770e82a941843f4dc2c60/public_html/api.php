<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$usersFile = 'users.json';
$markersFile = 'markers.json';

if (!file_exists($usersFile)) file_put_contents($usersFile, json_encode([]));
if (!file_exists($markersFile)) file_put_contents($markersFile, json_encode([]));

$data = json_decode(file_get_contents('php://input'), true);
$action = $_GET['action'] ?? '';

function saveJson($file, $data) {
  file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

switch ($action) {
  case 'register':
    $users = json_decode(file_get_contents($usersFile), true);
    foreach ($users as $u) {
      if ($u['nick'] === $data['nick']) {
        echo json_encode(['success' => false, 'message' => 'Ник уже занят']);
        exit;
      }
    }
    $users[] = $data;
    saveJson($usersFile, $users);
    echo json_encode(['success' => true, 'message' => 'Пользователь зарегистрирован']);
    break;

  case 'login':
    $users = json_decode(file_get_contents($usersFile), true);
    foreach ($users as $u) {
      if ($u['nick'] === $data['nick'] && $u['password'] === $data['password']) {
        echo json_encode(['success' => true]);
        exit;
      }
    }
    echo json_encode(['success' => false, 'message' => 'Неверный логин или пароль']);
    break;

case 'deleteAll':
  $markers = json_decode(file_get_contents($markersFile), true);
  $markers = array_filter($markers, fn($m) => $m['nick'] !== $data['nick']);
  saveJson($markersFile, array_values($markers));
  echo json_encode(['success' => true]);
  break;

  case 'add':
    $markers = json_decode(file_get_contents($markersFile), true);
    $now = time() * 1000;
    $markers = array_filter($markers, fn($m) => ($now - $m['timestamp']) < 7200000);
    $markers[] = $data;
    saveJson($markersFile, $markers);
    echo json_encode(['success' => true]);
    break;

  case 'delete':
    $markers = json_decode(file_get_contents($markersFile), true);
    $markers = array_filter($markers, function($m) use ($data) {
      return !(abs($m['coords'][0] - $data['lat']) < 0.00001 &&
               abs($m['coords'][1] - $data['lon']) < 0.00001 &&
               $m['nick'] === $data['nick']);
    });
    saveJson($markersFile, array_values($markers));
    echo json_encode(['success' => true]);
    break;

  case 'markers':
    $markers = json_decode(file_get_contents($markersFile), true);
    $now = time() * 1000;
    $filtered = array_filter($markers, fn($m) => ($now - $m['timestamp']) < 7200000);
    echo json_encode(array_values($filtered));
    break;

  default:
    echo json_encode(['error' => 'Unknown action']);
}
