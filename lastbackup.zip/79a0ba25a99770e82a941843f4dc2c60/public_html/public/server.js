const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const FILE = 'markers.json';

// Загружаем метки
function loadMarkers() {
  try {
    const data = fs.readFileSync(FILE, 'utf-8');
    return JSON.parse(data).filter(m => Date.now() - m.timestamp < 3600000);
  } catch {
    return [];
  }
}

// Сохраняем метки
function saveMarkers(markers) {
  fs.writeFileSync(FILE, JSON.stringify(markers, null, 2));
}

// Получить актуальные метки
app.get('/api/markers', (req, res) => {
  res.json(loadMarkers());
});

// Добавить новую метку
app.post('/api/markers', (req, res) => {
  const markers = loadMarkers();
  markers.push(req.body);
  saveMarkers(markers);
  res.json({ status: 'ok' });
});

app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});
